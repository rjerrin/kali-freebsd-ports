/*
 * Copyright (c) 2014-2016 Cesanta Software Limited
 * All rights reserved
 */

int main(int argc, char *argv[]) {
  return 0;
}
