fuser -k -n tcp 40111
