#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include "mem_ops.h"

//read lines of file
bool allowlist_ip(char * addr);
