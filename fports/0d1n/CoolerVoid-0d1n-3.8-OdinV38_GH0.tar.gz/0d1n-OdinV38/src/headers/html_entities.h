#ifndef HTML_ENTITIES_H__
#define HTML_ENTITIES_H__
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *html_entities(const char *str); 

#endif
